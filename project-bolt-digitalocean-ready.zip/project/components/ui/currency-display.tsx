"use client"

import { formatDualCurrency } from "@/lib/currency/exchange"

interface CurrencyDisplayProps {
  amountUSD: number
  showDual?: boolean
}

export function CurrencyDisplay({ amountUSD, showDual = false }: CurrencyDisplayProps) {
  if (showDual) {
    return <span>{formatDualCurrency(amountUSD)}</span>
  }
  return <span>${amountUSD.toFixed(2)}</span>
}