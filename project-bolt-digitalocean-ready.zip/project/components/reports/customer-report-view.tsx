"use client"

import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { TokenHistory } from "@/components/tokens/token-history"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"

// Mock data - In a real app, this would come from an API
const customerData = {
  personalInfo: {
    name: "John Doe",
    email: "john@example.com",
    phone: "+1234567890",
    nationalId: "ID123456",
    county: "Montserrado",
    district: "District 1",
    address: "123 Main St",
    registrationDate: "2024-01-15",
  },
  products: [
    {
      id: "1",
      name: "Basic Solar Kit",
      serialNumber: "BSK001",
      installationDate: "2024-01-20",
      status: "active",
      plan: "6 months",
      remainingBalance: 450,
      nextPaymentDue: "2024-02-20",
    }
  ],
  payments: [
    {
      id: "1",
      date: "2024-01-15",
      amount: 150,
      method: "Mobile Money",
      reference: "MM123456",
      status: "successful",
    },
    {
      id: "2",
      date: "2024-02-15",
      amount: 150,
      method: "Mobile Money",
      reference: "MM123457",
      status: "successful",
    }
  ],
  serviceHistory: [
    {
      id: "1",
      date: "2024-01-20",
      type: "Installation",
      technician: "Mike Wilson",
      status: "completed",
      notes: "Initial installation completed successfully",
    },
    {
      id: "2",
      date: "2024-02-10",
      type: "Maintenance",
      technician: "Sarah Johnson",
      status: "completed",
      notes: "Regular maintenance check - all systems working properly",
    }
  ]
}

interface CustomerReportViewProps {
  nationalId: string
}

export function CustomerReportView({ nationalId }: CustomerReportViewProps) {
  return (
    <div className="space-y-6">
      <Card className="p-6">
        <h2 className="text-lg font-medium mb-4">Personal Information</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          <div>
            <p className="text-sm text-muted-foreground">Name</p>
            <p className="font-medium">{customerData.personalInfo.name}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Email</p>
            <p className="font-medium">{customerData.personalInfo.email}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Phone</p>
            <p className="font-medium">{customerData.personalInfo.phone}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">National ID</p>
            <p className="font-medium">{customerData.personalInfo.nationalId}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">County</p>
            <p className="font-medium">{customerData.personalInfo.county}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">District</p>
            <p className="font-medium">{customerData.personalInfo.district}</p>
          </div>
          <div className="col-span-2">
            <p className="text-sm text-muted-foreground">Address</p>
            <p className="font-medium">{customerData.personalInfo.address}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Registration Date</p>
            <p className="font-medium">{customerData.personalInfo.registrationDate}</p>
          </div>
        </div>
      </Card>

      <Tabs defaultValue="products" className="w-full">
        <TabsList>
          <TabsTrigger value="products">Products</TabsTrigger>
          <TabsTrigger value="payments">Payment History</TabsTrigger>
          <TabsTrigger value="tokens">Token History</TabsTrigger>
          <TabsTrigger value="service">Service History</TabsTrigger>
        </TabsList>

        <TabsContent value="products" className="mt-6">
          <Card className="p-6">
            <h3 className="text-lg font-medium mb-4">Installed Products</h3>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Product</TableHead>
                  <TableHead>Serial Number</TableHead>
                  <TableHead>Installation Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Plan</TableHead>
                  <TableHead>Balance</TableHead>
                  <TableHead>Next Payment</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {customerData.products.map((product) => (
                  <TableRow key={product.id}>
                    <TableCell>{product.name}</TableCell>
                    <TableCell className="font-mono">{product.serialNumber}</TableCell>
                    <TableCell>{product.installationDate}</TableCell>
                    <TableCell>
                      <Badge variant={product.status === "active" ? "default" : "secondary"}>
                        {product.status}
                      </Badge>
                    </TableCell>
                    <TableCell>{product.plan}</TableCell>
                    <TableCell>${product.remainingBalance}</TableCell>
                    <TableCell>{product.nextPaymentDue}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Card>
        </TabsContent>

        <TabsContent value="payments" className="mt-6">
          <Card className="p-6">
            <h3 className="text-lg font-medium mb-4">Payment History</h3>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Method</TableHead>
                  <TableHead>Reference</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {customerData.payments.map((payment) => (
                  <TableRow key={payment.id}>
                    <TableCell>{payment.date}</TableCell>
                    <TableCell>${payment.amount}</TableCell>
                    <TableCell>{payment.method}</TableCell>
                    <TableCell className="font-mono">{payment.reference}</TableCell>
                    <TableCell>
                      <Badge variant={payment.status === "successful" ? "default" : "secondary"}>
                        {payment.status}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Card>
        </TabsContent>

        <TabsContent value="tokens" className="mt-6">
          <TokenHistory customerId="1" showFilters={false} />
        </TabsContent>

        <TabsContent value="service" className="mt-6">
          <Card className="p-6">
            <h3 className="text-lg font-medium mb-4">Service History</h3>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Technician</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Notes</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {customerData.serviceHistory.map((service) => (
                  <TableRow key={service.id}>
                    <TableCell>{service.date}</TableCell>
                    <TableCell>{service.type}</TableCell>
                    <TableCell>{service.technician}</TableCell>
                    <TableCell>
                      <Badge variant={service.status === "completed" ? "default" : "secondary"}>
                        {service.status}
                      </Badge>
                    </TableCell>
                    <TableCell>{service.notes}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}