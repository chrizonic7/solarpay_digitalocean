"use client"

import { useState } from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { toast } from "sonner"
import { convertLRDtoUSD, convertUSDtoLRD, formatCurrency } from "@/lib/currency/exchange"
import { CurrencyDisplay } from "@/components/ui/currency-display"

const formSchema = z.object({
  amount: z.string().min(1, "Amount is required"),
  currency: z.enum(["USD", "LRD"]),
  paymentMethod: z.string().min(1, "Please select a payment method"),
  phoneNumber: z.string().min(10, "Phone number must be at least 10 digits").optional(),
})

interface CustomerPaymentDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

const paymentMethods = {
  momo: {
    label: "Mobile Money",
    currencies: ["LRD"],
  },
  cash: {
    label: "Cash",
    currencies: ["USD", "LRD"],
  },
}

export function CustomerPaymentDialog({ open, onOpenChange }: CustomerPaymentDialogProps) {
  const [isLoading, setIsLoading] = useState(false)
  const [selectedMethod, setSelectedMethod] = useState<string>("")

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      amount: "",
      currency: "USD",
      paymentMethod: "",
      phoneNumber: "",
    },
  })

  const watchAmount = form.watch("amount")
  const watchCurrency = form.watch("currency")
  const watchPaymentMethod = form.watch("paymentMethod")

  // Get available currencies based on selected payment method
  const getAvailableCurrencies = () => {
    if (!watchPaymentMethod) return ["USD", "LRD"]
    return paymentMethods[watchPaymentMethod as keyof typeof paymentMethods]?.currencies || ["USD", "LRD"]
  }

  // Update currency if current selection is not available for new payment method
  const handlePaymentMethodChange = (method: string) => {
    setSelectedMethod(method)
    form.setValue("paymentMethod", method)

    const availableCurrencies = paymentMethods[method as keyof typeof paymentMethods]?.currencies || []
    if (!availableCurrencies.includes(watchCurrency)) {
      form.setValue("currency", availableCurrencies[0])
    }
  }

  const getEquivalentAmount = () => {
    if (!watchAmount) return null
    
    const amount = parseFloat(watchAmount)
    if (isNaN(amount)) return null

    if (watchCurrency === "USD") {
      const lrdAmount = convertUSDtoLRD(amount)
      return `${formatCurrency(amount, "USD")} = ${formatCurrency(lrdAmount, "LRD")}`
    } else {
      const usdAmount = convertLRDtoUSD(amount)
      return `${formatCurrency(amount, "LRD")} = ${formatCurrency(usdAmount, "USD")}`
    }
  }

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsLoading(true)
    try {
      // Convert amount to USD for processing
      const amountUSD = values.currency === "USD" 
        ? parseFloat(values.amount)
        : convertLRDtoUSD(parseFloat(values.amount))

      // Simulate payment processing
      await new Promise((resolve) => setTimeout(resolve, 2000))
      
      toast.success(
        <div className="space-y-2">
          <p>Payment processed successfully!</p>
          <p className="text-sm text-muted-foreground">
            Amount paid: <CurrencyDisplay amountUSD={amountUSD} showDual />
          </p>
          <p className="text-sm text-muted-foreground">
            New token will be activated shortly.
          </p>
        </div>
      )

      onOpenChange(false)
      form.reset()
    } catch (error) {
      toast.error("Failed to process payment. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Make a Payment</DialogTitle>
          <DialogDescription>
            Pay for your solar system and receive a new token
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="paymentMethod"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Payment Method</FormLabel>
                  <Select 
                    onValueChange={handlePaymentMethodChange}
                    value={field.value}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select payment method" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {Object.entries(paymentMethods).map(([value, { label }]) => (
                        <SelectItem key={value} value={value}>
                          {label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {watchPaymentMethod && (
                    <FormDescription>
                      Accepted currencies: {getAvailableCurrencies().join(", ")}
                    </FormDescription>
                  )}
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex gap-4">
              <FormField
                control={form.control}
                name="amount"
                render={({ field }) => (
                  <FormItem className="flex-1">
                    <FormLabel>Amount</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        placeholder="0.00" 
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="currency"
                render={({ field }) => (
                  <FormItem className="w-[100px]">
                    <FormLabel>Currency</FormLabel>
                    <Select 
                      onValueChange={field.onChange}
                      value={field.value}
                      disabled={!watchPaymentMethod}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Currency" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {getAvailableCurrencies().map(currency => (
                          <SelectItem key={currency} value={currency}>
                            {currency}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {getEquivalentAmount() && (
              <FormDescription className="text-center">
                {getEquivalentAmount()}
              </FormDescription>
            )}

            {selectedMethod === "momo" && (
              <FormField
                control={form.control}
                name="phoneNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Mobile Money Number</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="+1234567890"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}

            <DialogFooter>
              <Button type="submit" disabled={isLoading} className="w-full">
                {isLoading ? (
                  "Processing Payment..."
                ) : (
                  `Pay ${getEquivalentAmount() || `${watchCurrency} ${watchAmount || "0.00"}`}`
                )}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  )
}