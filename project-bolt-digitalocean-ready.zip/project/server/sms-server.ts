import express from 'express';
import { sendSMS, sendTokenSMS } from '../lib/sms/africa-talking';

const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Handle incoming messages
app.post('/webhook/sms', async (req, res) => {
  try {
    const { from, text, date } = req.body;
    console.log('Received SMS:', { from, text, date });

    // Store message in database or process it
    // TODO: Implement message processing logic

    res.status(200).json({ success: true });
  } catch (error) {
    console.error('Error processing incoming SMS:', error);
    res.status(500).json({ success: false, error: 'Failed to process message' });
  }
});

// Handle delivery reports
app.post('/webhook/delivery', async (req, res) => {
  try {
    const { phoneNumber, status, messageId } = req.body;
    console.log('Delivery Report:', { phoneNumber, status, messageId });

    // Update message status in database
    // TODO: Implement status update logic

    res.status(200).json({ success: true });
  } catch (error) {
    console.error('Error processing delivery report:', error);
    res.status(500).json({ success: false, error: 'Failed to process delivery report' });
  }
});

// Test route to send SMS
app.post('/api/test-sms', async (req, res) => {
  try {
    const { to, message } = req.body;
    
    const response = await sendSMS({
      to,
      message
    });

    if (!response.success) {
      throw new Error(response.error);
    }

    res.status(200).json({
      success: true,
      data: response.data
    });
  } catch (error) {
    console.error('Error sending test SMS:', error);
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : 'Failed to send SMS'
    });
  }
});

// Send token via SMS
app.post('/api/send-token', async (req, res) => {
  try {
    const { to, token, expiryDate } = req.body;
    
    const response = await sendTokenSMS({
      to,
      token,
      expiryDate
    });

    if (!response.success) {
      throw new Error(response.error);
    }

    res.status(200).json({
      success: true,
      data: response.data
    });
  } catch (error) {
    console.error('Error sending token SMS:', error);
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : 'Failed to send token'
    });
  }
});

const port = process.env.SMS_SERVER_PORT || 3001;

export function startSMSServer() {
  return new Promise((resolve, reject) => {
    try {
      const server = app.listen(port, () => {
        console.log(`SMS Server running on port: ${port}`);
        resolve(server);
      });
    } catch (error) {
      console.error('Failed to start SMS server:', error);
      reject(error);
    }
  });
}