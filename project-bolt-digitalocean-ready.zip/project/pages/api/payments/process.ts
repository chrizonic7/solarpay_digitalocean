import { NextApiRequest, NextApiResponse } from 'next';
import { sendTokenSMS } from '@/lib/sms/africa-talking';
import { format, addMonths } from 'date-fns';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Method not allowed' });
  }

  try {
    const { customerId, amount, phone, token } = req.body;

    // In a real app:
    // 1. Validate payment
    // 2. Generate or fetch token
    // 3. Update database
    // 4. Calculate expiry date based on payment plan

    // Example expiry date calculation (1 month from now)
    const expiryDate = format(addMonths(new Date(), 1), 'PPP');

    // Send SMS with token
    const smsResponse = await sendTokenSMS({
      to: phone,
      token: token,
      expiryDate
    });

    if (!smsResponse.success) {
      throw new Error('Failed to send token SMS');
    }

    return res.status(200).json({
      success: true,
      message: 'Payment processed and token sent successfully',
      data: {
        token,
        expiryDate,
        smsStatus: smsResponse.data
      }
    });

  } catch (error) {
    console.error('Error processing payment:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to process payment',
      error: error instanceof Error ? error.message : 'Unknown error'
    });
  }
}