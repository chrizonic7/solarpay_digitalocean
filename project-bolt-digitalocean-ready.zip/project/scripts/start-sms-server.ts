import { startSMSServer } from '../server/sms-server';

async function main() {
  try {
    await startSMSServer();
    console.log('SMS Server started successfully');
    
    // Send test message
    const testMessage = {
      to: '+231886777716',
      message: 'SMS Server is up and running!'
    };

    const response = await fetch('http://localhost:3001/api/test-sms', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(testMessage)
    });

    const result = await response.json();
    
    if (result.success) {
      console.log('Test message sent successfully:', result.data);
    } else {
      console.error('Failed to send test message:', result.error);
    }
  } catch (error) {
    console.error('Error starting SMS server:', error);
    process.exit(1);
  }
}

main();