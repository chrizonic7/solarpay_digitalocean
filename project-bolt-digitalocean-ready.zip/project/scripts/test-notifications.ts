import { sendWelcomeEmail } from '../lib/email/send-email';
import { sendSMS } from '../lib/sms/send-sms';

async function testNotifications() {
  try {
    // Test email
    console.log('Testing email...');
    const emailResult = await sendWelcomeEmail({
      to: 'test@example.com',
      name: 'Test User',
      role: 'admin',
      temporaryPassword: 'TestPass123!',
      setupLink: 'http://localhost:3000/setup'
    });

    console.log('Email result:', emailResult);

    // Test SMS
    console.log('\nTesting SMS...');
    const smsResult = await sendSMS({
      to: '231886777716',
      message: 'Test message from BBTECH Africa Energy'
    });

    console.log('SMS result:', smsResult);
  } catch (error) {
    console.error('Error testing notifications:', error);
  }
}

testNotifications();