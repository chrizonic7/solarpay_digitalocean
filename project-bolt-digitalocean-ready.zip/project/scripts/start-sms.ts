import { startSMSServer } from '../server/sms-server';
import { sendSMS } from '../lib/sms/africa-talking';

async function main() {
  try {
    // Start SMS server
    await startSMSServer();
    console.log('SMS Server started successfully');

    // Send test message
    const response = await sendSMS({
      to: '+231886777716',
      message: 'SMS Server is up and running!'
    });

    if (response.success) {
      console.log('Test message sent successfully:', response.data);
    } else {
      console.error('Failed to send test message:', response.error);
    }
  } catch (error) {
    console.error('Error:', error);
    process.exit(1);
  }
}

main();