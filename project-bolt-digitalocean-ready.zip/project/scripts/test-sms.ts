import { sendSMS } from '../lib/sms/africa-talking';

async function testSMS() {
  try {
    console.log('Sending test SMS...');
    
    const response = await sendSMS({
      to: '231886777716', // Number will be formatted with '+' automatically
      message: 'Test SMS from BBTECH Africa Energy - ' + new Date().toLocaleString()
    });

    if (response.success) {
      console.log('SMS sent successfully!');
      console.log('Response:', JSON.stringify(response.data, null, 2));
    } else {
      console.error('Failed to send SMS:', response.error);
    }
  } catch (error) {
    console.error('Error testing SMS:', error);
  }
}

testSMS();