import { setupDomain, verifyDomain } from '../lib/email/setup-domain';
import { getDomainStatus } from '../lib/email/domain-utils';

async function main() {
  // First check if domain already exists
  const status = await getDomainStatus();
  
  if (status.success) {
    if (status.data.exists) {
      console.log('Domain already exists with status:', status.data.status);
      
      if (status.data.status !== 'verified') {
        console.log('Attempting to verify existing domain...');
        const verification = await verifyDomain();
        
        if (verification.success) {
          console.log('Domain verified successfully!');
          console.log('Verification details:', verification.data);
        } else {
          console.error('Failed to verify domain:', verification.error);
        }
      }
    } else {
      console.log('Setting up new domain...');
      const setup = await setupDomain();
      
      if (setup.success) {
        console.log('Domain setup successful!');
        console.log('\nDNS Records to configure:');
        setup.data.records.forEach((record: any) => {
          console.log(`\nType: ${record.type}`);
          console.log(`Name: ${record.name}`);
          console.log(`Value: ${record.value}`);
          if (record.ttl) console.log(`TTL: ${record.ttl}`);
        });
        
        console.log('\nPlease add these DNS records to your domain provider.');
        console.log('After adding DNS records, run this script again to verify the domain.');
      } else {
        console.error('Failed to setup domain:', setup.error);
      }
    }
  } else {
    console.error('Failed to check domain status:', status.error);
  }
}

main().catch(console.error);