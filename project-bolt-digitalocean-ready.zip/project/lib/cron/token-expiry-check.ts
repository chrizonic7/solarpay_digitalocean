import cron from 'node-cron';
import { addDays, parseISO, format } from 'date-fns';
import { sendTokenExpiryReminder } from '../sms/africa-talking';

// Mock data - In real app, this would come from your database
interface Token {
  id: string;
  token: string;
  customerId: string;
  customerPhone: string;
  expiryDate: string;
  notificationSent?: boolean;
}

async function checkExpiringTokens() {
  try {
    // In a real app, fetch tokens from your database
    const tokens: Token[] = []; // Replace with database query
    const today = new Date();
    const sevenDaysFromNow = addDays(today, 7);

    for (const token of tokens) {
      const expiryDate = parseISO(token.expiryDate);
      
      // Check if token expires in 7 days and notification hasn't been sent
      if (!token.notificationSent && 
          expiryDate <= sevenDaysFromNow && 
          expiryDate > today) {
        
        const daysRemaining = Math.ceil((expiryDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
        
        await sendTokenExpiryReminder({
          to: token.customerPhone,
          token: token.token,
          expiryDate: format(expiryDate, 'PPP'),
          daysRemaining
        });

        // Update token in database to mark notification as sent
        // await updateToken(token.id, { notificationSent: true });
      }
    }
  } catch (error) {
    console.error('Error checking expiring tokens:', error);
  }
}

// Run every day at 9:00 AM
export function startTokenExpiryCheck() {
  cron.schedule('0 9 * * *', checkExpiringTokens);
}