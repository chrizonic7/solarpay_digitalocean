import AfricasTalking from 'africastalking';

// Initialize the SDK
const africastalking = AfricasTalking({
  apiKey: process.env.AT_API_KEY || '',
  username: process.env.AT_USERNAME || 'sandbox'
});

const sms = africastalking.SMS;

interface SendSMSParams {
  to: string | string[];
  message: string;
  from?: string;
}

interface SMSResponse {
  success: boolean;
  data?: any;
  error?: string;
}

export async function sendSMS({ to, message, from }: SendSMSParams): Promise<SMSResponse> {
  try {
    // Format phone numbers to ensure they start with '+'
    const formattedNumbers = Array.isArray(to) 
      ? to.map(num => num.startsWith('+') ? num : `+${num}`)
      : to.startsWith('+') ? to : `+${to}`;

    const response = await sms.send({
      to: Array.isArray(formattedNumbers) ? formattedNumbers.join(',') : formattedNumbers,
      message,
      from: from || process.env.AT_SENDER_ID || 'BBTECH'
    });

    console.log('SMS Response:', response);
    return {
      success: true,
      data: response
    };
  } catch (error) {
    console.error('Error sending SMS:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Failed to send SMS'
    };
  }
}

export async function sendTokenSMS({ to, token, expiryDate }: {
  to: string;
  token: string;
  expiryDate: string;
}): Promise<SMSResponse> {
  const message = `Your BBTECH Solar token: ${token}\nValid until: ${expiryDate}\n\nThank you for choosing BBTECH Africa Energy!`;
  return sendSMS({ to, message });
}

export async function sendTokenExpiryReminder({
  to,
  token,
  expiryDate,
  daysRemaining
}: {
  to: string;
  token: string;
  expiryDate: string;
  daysRemaining: number;
}): Promise<SMSResponse> {
  const message = `REMINDER: Your BBTECH Solar token (${token}) will expire in ${daysRemaining} days on ${expiryDate}. Please make payment to avoid service interruption.`;
  return sendSMS({ to, message });
}