import AfricasTalking from 'africastalking';

const africastalking = AfricasTalking({
  apiKey: process.env.AT_API_KEY || '',
  username: process.env.AT_USERNAME || 'sandbox'
});

interface SendSMSParams {
  to: string | string[];
  message: string;
  from?: string;
}

export async function sendSMS({ to, message, from }: SendSMSParams) {
  try {
    // Ensure phone numbers start with '+'
    const formattedNumbers = Array.isArray(to) 
      ? to.map(num => num.startsWith('+') ? num : `+${num}`)
      : [to.startsWith('+') ? to : `+${to}`];

    const response = await africastalking.SMS.send({
      to: formattedNumbers,
      message,
      from: from || process.env.AT_SENDER_ID || 'BBTECH'
    });

    return { success: true, data: response };
  } catch (error) {
    console.error('Error sending SMS:', error);
    return { 
      success: false, 
      error: error instanceof Error ? error.message : 'Failed to send SMS'
    };
  }
}