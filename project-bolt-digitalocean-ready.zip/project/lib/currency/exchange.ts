interface ExchangeRate {
  USD_to_LRD: number;
  lastUpdated: Date;
}

// In a real app, this would be stored in a database
let currentRate: ExchangeRate = {
  USD_to_LRD: 175.50,
  lastUpdated: new Date()
};

export function getExchangeRate(): ExchangeRate {
  return currentRate;
}

export function updateExchangeRate(newRate: number): ExchangeRate {
  currentRate = {
    USD_to_LRD: newRate,
    lastUpdated: new Date()
  };
  return currentRate;
}

export function convertUSDtoLRD(amountUSD: number): number {
  return amountUSD * currentRate.USD_to_LRD;
}

export function convertLRDtoUSD(amountLRD: number): number {
  return amountLRD / currentRate.USD_to_LRD;
}

export function formatCurrency(amount: number, currency: "USD" | "LRD"): string {
  if (currency === "USD") {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  } else {
    return new Intl.NumberFormat('en-LR', {
      style: 'currency',
      currency: 'LRD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  }
}

export function formatDualCurrency(amountUSD: number): string {
  const amountLRD = convertUSDtoLRD(amountUSD);
  return `${formatCurrency(amountUSD, "USD")} / ${formatCurrency(amountLRD, "LRD")}`;
}