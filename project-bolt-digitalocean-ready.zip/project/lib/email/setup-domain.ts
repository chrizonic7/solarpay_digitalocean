import { Resend } from 'resend';

const resend = new Resend(process.env.RESEND_API_KEY);

export async function setupDomain() {
  try {
    // Create domain
    const domain = await resend.domains.create({
      name: 'bestbrainstech.com'
    });

    console.log('Domain created:', domain);

    // Get domain details and DNS records
    const domainDetails = await resend.domains.get(domain.data.id);
    console.log('DNS Records to add:', domainDetails.data.records);

    return {
      success: true,
      data: domainDetails.data
    };
  } catch (error) {
    console.error('Error setting up domain:', error);
    return {
      success: false,
      error
    };
  }
}

export async function verifyDomain() {
  try {
    const domains = await resend.domains.list();
    const domain = domains.data.find(d => d.name === 'bestbrainstech.com');

    if (!domain) {
      throw new Error('Domain not found');
    }

    const verification = await resend.domains.verify(domain.id);
    
    return {
      success: true,
      data: verification.data
    };
  } catch (error) {
    console.error('Error verifying domain:', error);
    return {
      success: false,
      error
    };
  }
}