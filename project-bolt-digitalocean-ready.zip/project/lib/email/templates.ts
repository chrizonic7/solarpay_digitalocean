export const emailTemplates = {
  admin: {
    subject: 'Welcome to SolarPay - Admin Account Setup',
    html: (data: { name: string; temporaryPassword: string; setupLink: string }) => `{
      "subject": "Welcome to SolarPay - Admin Account Setup",
      "html": "<div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;'><h2>Welcome to SolarPay</h2><p>Hello ${data.name},</p><p>You have been added as an Administrator.</p><p><strong>Temporary password:</strong> ${data.temporaryPassword}</p><p><a href='${data.setupLink}' style='background: #2563eb; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px;'>Set Up Account</a></p></div>"
    }`
  },
  agent: {
    subject: 'Welcome to SolarPay - Agent Account Setup',
    html: (data: { name: string; temporaryPassword: string; setupLink: string }) => `{
      "subject": "Welcome to SolarPay - Agent Account Setup",
      "html": "<div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;'><h2>Welcome to SolarPay</h2><p>Hello ${data.name},</p><p>You have been registered as a Sales Agent.</p><p><strong>Temporary password:</strong> ${data.temporaryPassword}</p><p><a href='${data.setupLink}' style='background: #2563eb; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px;'>Set Up Account</a></p></div>"
    }`
  },
  customer: {
    subject: 'Welcome to SolarPay - Account Setup',
    html: (data: { name: string; temporaryPassword: string; setupLink: string }) => `{
      "subject": "Welcome to SolarPay - Account Setup",
      "html": "<div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;'><h2>Welcome to SolarPay</h2><p>Hello ${data.name},</p><p>Your solar system account has been created.</p><p><strong>Temporary password:</strong> ${data.temporaryPassword}</p><p><a href='${data.setupLink}' style='background: #2563eb; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px;'>Set Up Account</a></p></div>"
    }`
  }
};