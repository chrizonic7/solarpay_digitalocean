import { Resend } from 'resend';
import { emailTemplates } from './templates';

const resend = new Resend(process.env.RESEND_API_KEY);

interface SendEmailParams {
  to: string;
  name: string;
  role: 'admin' | 'agent' | 'customer';
  temporaryPassword: string;
  setupLink: string;
}

export async function sendWelcomeEmail(params: SendEmailParams) {
  try {
    const template = emailTemplates[params.role];
    if (!template) {
      throw new Error(`Invalid role: ${params.role}`);
    }

    const emailData = JSON.parse(template.html({
      name: params.name,
      temporaryPassword: params.temporaryPassword,
      setupLink: params.setupLink
    }));

    const response = await resend.emails.send({
      from: 'SolarPay <noreply@bestbrainstech.com>',
      to: params.to,
      subject: emailData.subject,
      html: emailData.html
    });

    return { success: true, data: response };
  } catch (error) {
    console.error('Error sending email:', error);
    return { 
      success: false, 
      error: error instanceof Error ? error.message : 'Failed to send email'
    };
  }
}