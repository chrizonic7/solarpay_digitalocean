import { Resend } from 'resend';

const resend = new Resend(process.env.RESEND_API_KEY);

export async function getDomainInfo() {
  try {
    // First get list of domains to find the ID
    const domains = await resend.domains.list();
    const domain = domains.data.find(d => d.name === 'bestbrainstech.com');

    if (!domain) {
      throw new Error('Domain not found');
    }

    // Get detailed information about the domain
    const domainDetails = await resend.domains.get(domain.id);

    return {
      success: true,
      data: {
        ...domainDetails.data,
        status: domain.status,
        region: domain.region
      }
    };
  } catch (error) {
    console.error('Error retrieving domain information:', error);
    return {
      success: false,
      error
    };
  }
}

export async function getDomainStatus() {
  try {
    const domains = await resend.domains.list();
    const domain = domains.data.find(d => d.name === 'bestbrainstech.com');

    if (!domain) {
      return {
        success: true,
        data: {
          exists: false,
          status: null
        }
      };
    }

    return {
      success: true,
      data: {
        exists: true,
        status: domain.status,
        id: domain.id,
        region: domain.region,
        createdAt: domain.created_at
      }
    };
  } catch (error) {
    console.error('Error checking domain status:', error);
    return {
      success: false,
      error
    };
  }
}