import { Resend } from 'resend';

const resend = new Resend(process.env.RESEND_API_KEY);

interface EmailData {
  to: string;
  name: string;
  role: string;
  temporaryPassword?: string;
  setupLink: string;
}

const templates = {
  admin: {
    subject: 'Welcome to SolarPay - Admin Account Setup',
    html: (data: EmailData) => `
      <!DOCTYPE html>
      <html>
        <body style="font-family: Arial, sans-serif; margin: 0; padding: 20px; color: #333;">
          <div style="max-width: 600px; margin: 0 auto; background: white;">
            <h2 style="color: #2563eb;">Welcome to SolarPay</h2>
            <p>Hello ${data.name},</p>
            <p>You have been added as an Administrator to the SolarPay Management System.</p>
            <p><strong>Your temporary password is:</strong> ${data.temporaryPassword}</p>
            <div style="text-align: center; margin: 30px 0;">
              <a href="${data.setupLink}" 
                 style="background-color: #2563eb; color: white; padding: 12px 24px; 
                        text-decoration: none; border-radius: 5px; display: inline-block;">
                Set Up Account
              </a>
            </div>
            <p style="color: #666; font-size: 14px;">This link will expire in 24 hours.</p>
            <hr style="border: none; border-top: 1px solid #eee; margin: 20px 0;">
            <p>Best regards,<br>The SolarPay Team</p>
          </div>
        </body>
      </html>
    `
  },
  agent: {
    subject: 'Welcome to SolarPay - Agent Account Setup',
    html: (data: EmailData) => `
      <!DOCTYPE html>
      <html>
        <body style="font-family: Arial, sans-serif; margin: 0; padding: 20px; color: #333;">
          <div style="max-width: 600px; margin: 0 auto; background: white;">
            <h2 style="color: #2563eb;">Welcome to SolarPay</h2>
            <p>Hello ${data.name},</p>
            <p>Welcome to the SolarPay Sales Team! You have been registered as a Sales Agent.</p>
            <p><strong>Your temporary password is:</strong> ${data.temporaryPassword}</p>
            <div style="text-align: center; margin: 30px 0;">
              <a href="${data.setupLink}" 
                 style="background-color: #2563eb; color: white; padding: 12px 24px; 
                        text-decoration: none; border-radius: 5px; display: inline-block;">
                Set Up Account
              </a>
            </div>
            <p style="color: #666; font-size: 14px;">This link will expire in 24 hours.</p>
            <hr style="border: none; border-top: 1px solid #eee; margin: 20px 0;">
            <p>Best regards,<br>The SolarPay Team</p>
          </div>
        </body>
      </html>
    `
  },
  customer: {
    subject: 'Welcome to SolarPay - Account Setup',
    html: (data: EmailData) => `
      <!DOCTYPE html>
      <html>
        <body style="font-family: Arial, sans-serif; margin: 0; padding: 20px; color: #333;">
          <div style="max-width: 600px; margin: 0 auto; background: white;">
            <h2 style="color: #2563eb;">Welcome to SolarPay</h2>
            <p>Hello ${data.name},</p>
            <p>Welcome to SolarPay! Your solar system account has been created.</p>
            <p><strong>Your temporary password is:</strong> ${data.temporaryPassword}</p>
            <div style="text-align: center; margin: 30px 0;">
              <a href="${data.setupLink}" 
                 style="background-color: #2563eb; color: white; padding: 12px 24px; 
                        text-decoration: none; border-radius: 5px; display: inline-block;">
                Set Up Account
              </a>
            </div>
            <p style="color: #666; font-size: 14px;">This link will expire in 24 hours.</p>
            <hr style="border: none; border-top: 1px solid #eee; margin: 20px 0;">
            <p>Best regards,<br>The SolarPay Team</p>
          </div>
        </body>
      </html>
    `
  }
};

export async function sendWelcomeEmail(data: EmailData) {
  const template = templates[data.role as keyof typeof templates];
  
  if (!template) {
    throw new Error(`Invalid role: ${data.role}`);
  }

  try {
    const response = await resend.emails.send({
      from: 'SolarPay <noreply@bestbrainstech.com>',
      to: data.email,
      subject: template.subject,
      html: template.html(data),
    });

    return { success: true, data: response };
  } catch (error) {
    console.error('Error sending email:', error);
    return { 
      success: false, 
      error: error instanceof Error ? error : new Error('Unknown error sending email')
    };
  }
}