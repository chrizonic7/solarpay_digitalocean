import sgMail from '@sendgrid/mail';

// Initialize SendGrid with your API key
sgMail.setApiKey(process.env.SENDGRID_API_KEY || '');

interface EmailData {
  to: string;
  name: string;
  role: string;
  temporaryPassword?: string;
  setupLink: string;
}

const templates = {
  admin: {
    subject: 'Welcome to SolarPay - Admin Account Setup',
    text: (data: EmailData) => `
Hello ${data.name},

You have been added as an Administrator to the SolarPay Management System.

Your temporary password is: ${data.temporaryPassword}

Please click the following link to set up your account:
${data.setupLink}

This link will expire in 24 hours.

Best regards,
The SolarPay Team
    `,
    html: (data: EmailData) => `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2>Welcome to SolarPay</h2>
        <p>Hello ${data.name},</p>
        <p>You have been added as an Administrator to the SolarPay Management System.</p>
        <p><strong>Your temporary password is:</strong> ${data.temporaryPassword}</p>
        <p>Please click the button below to set up your account:</p>
        <p style="text-align: center;">
          <a href="${data.setupLink}" 
             style="background-color: #0070f3; color: white; padding: 12px 24px; 
                    text-decoration: none; border-radius: 5px; display: inline-block;">
            Set Up Account
          </a>
        </p>
        <p style="color: #666; font-size: 14px;">This link will expire in 24 hours.</p>
        <p>Best regards,<br>The SolarPay Team</p>
      </div>
    `
  },
  agent: {
    subject: 'Welcome to SolarPay - Agent Account Setup',
    text: (data: EmailData) => `
Hello ${data.name},

Welcome to the SolarPay Sales Team! You have been registered as a Sales Agent.

Your temporary password is: ${data.temporaryPassword}

Please click the following link to set up your account:
${data.setupLink}

This link will expire in 24 hours.

Best regards,
The SolarPay Team
    `,
    html: (data: EmailData) => `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2>Welcome to SolarPay</h2>
        <p>Hello ${data.name},</p>
        <p>Welcome to the SolarPay Sales Team! You have been registered as a Sales Agent.</p>
        <p><strong>Your temporary password is:</strong> ${data.temporaryPassword}</p>
        <p>Please click the button below to set up your account:</p>
        <p style="text-align: center;">
          <a href="${data.setupLink}" 
             style="background-color: #0070f3; color: white; padding: 12px 24px; 
                    text-decoration: none; border-radius: 5px; display: inline-block;">
            Set Up Account
          </a>
        </p>
        <p style="color: #666; font-size: 14px;">This link will expire in 24 hours.</p>
        <p>Best regards,<br>The SolarPay Team</p>
      </div>
    `
  },
  customer: {
    subject: 'Welcome to SolarPay - Account Setup',
    text: (data: EmailData) => `
Hello ${data.name},

Welcome to SolarPay! Your solar system account has been created.

Your temporary password is: ${data.temporaryPassword}

Please click the following link to set up your account:
${data.setupLink}

This link will expire in 24 hours.

Best regards,
The SolarPay Team
    `,
    html: (data: EmailData) => `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2>Welcome to SolarPay</h2>
        <p>Hello ${data.name},</p>
        <p>Welcome to SolarPay! Your solar system account has been created.</p>
        <p><strong>Your temporary password is:</strong> ${data.temporaryPassword}</p>
        <p>Please click the button below to set up your account:</p>
        <p style="text-align: center;">
          <a href="${data.setupLink}" 
             style="background-color: #0070f3; color: white; padding: 12px 24px; 
                    text-decoration: none; border-radius: 5px; display: inline-block;">
            Set Up Account
          </a>
        </p>
        <p style="color: #666; font-size: 14px;">This link will expire in 24 hours.</p>
        <p>Best regards,<br>The SolarPay Team</p>
      </div>
    `
  }
};

export async function sendWelcomeEmail(data: EmailData) {
  const template = templates[data.role as keyof typeof templates];
  
  if (!template) {
    throw new Error(`Invalid role: ${data.role}`);
  }

  const msg = {
    to: data.to,
    from: process.env.SENDGRID_FROM_EMAIL || 'noreply@solarpay.com',
    subject: template.subject,
    text: template.text(data),
    html: template.html(data),
  };

  try {
    await sgMail.send(msg);
    return { success: true };
  } catch (error) {
    console.error('Error sending email:', error);
    return { success: false, error };
  }
}