import { sendWelcomeEmail } from '@/lib/email/resend';

interface UserData {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'agent' | 'customer';
  temporaryPassword: string;
}

export async function sendUserSetupNotification(userData: UserData) {
  try {
    // Generate setup link
    const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000';
    const setupToken = Buffer.from(`${userData.id}-${Date.now()}`).toString('base64');
    const setupLink = `${baseUrl}/auth/setup?token=${setupToken}`;

    // Send welcome email
    const emailResult = await sendWelcomeEmail({
      to: userData.email,
      name: userData.name,
      role: userData.role,
      temporaryPassword: userData.temporaryPassword,
      setupLink,
    });

    if (!emailResult.success) {
      throw new Error(emailResult.error?.message || 'Failed to send welcome email');
    }

    return {
      success: true,
      setupLink,
      setupToken
    };
  } catch (error) {
    console.error('Error sending user setup notification:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Failed to send notification'
    };
  }
}