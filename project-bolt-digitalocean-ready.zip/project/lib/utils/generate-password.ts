export function generateTemporaryPassword(length: number = 12): string {
  const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*";
  let password = "";
  
  // Ensure at least one of each required character type
  password += charset.match(/[A-Z]/)[0]; // Uppercase
  password += charset.match(/[a-z]/)[0]; // Lowercase
  password += charset.match(/[0-9]/)[0]; // Number
  password += charset.match(/[!@#$%^&*]/)[0]; // Special character
  
  // Fill the rest randomly
  for (let i = password.length; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * charset.length);
    password += charset[randomIndex];
  }
  
  // Shuffle the password
  return password.split('').sort(() => Math.random() - 0.5).join('');
}