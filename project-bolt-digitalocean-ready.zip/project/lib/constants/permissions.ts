export const availablePermissions = {
  admin: [
    { id: "manage_users", label: "Manage Users" },
    { id: "manage_inventory", label: "Manage Inventory" },
    { id: "manage_agents", label: "Manage Agents" },
    { id: "view_reports", label: "View Reports" },
    { id: "manage_settings", label: "Manage Settings" },
  ],
  agent: [
    { id: "manage_customers", label: "Manage Customers" },
    { id: "view_inventory", label: "View Inventory" },
    { id: "generate_tokens", label: "Generate Tokens" },
    { id: "view_reports", label: "View Reports" },
  ],
} as const;