"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Search, Download } from "lucide-react"
import { CustomerReportView } from "@/components/reports/customer-report-view"

export default function CustomerReportPage() {
  const [nationalId, setNationalId] = useState("")
  const [isSearching, setIsSearching] = useState(false)
  const [hasSearched, setHasSearched] = useState(false)

  const handleSearch = async () => {
    setIsSearching(true)
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 1000))
    setHasSearched(true)
    setIsSearching(false)
  }

  return (
    <div className="p-8 space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Customer Report</h1>
        <p className="text-muted-foreground">Search and view detailed customer information</p>
      </div>

      <Card className="p-6">
        <div className="flex gap-4 mb-8">
          <div className="relative flex-1 max-w-sm">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Enter National ID..."
              value={nationalId}
              onChange={(e) => setNationalId(e.target.value)}
              className="pl-9"
            />
          </div>
          <Button 
            onClick={handleSearch} 
            disabled={!nationalId || isSearching}
          >
            {isSearching ? "Searching..." : "Search"}
          </Button>
          <Button variant="outline">
            <Download className="mr-2 h-4 w-4" />
            Export Report
          </Button>
        </div>

        {hasSearched && <CustomerReportView nationalId={nationalId} />}
      </Card>
    </div>
  )
}